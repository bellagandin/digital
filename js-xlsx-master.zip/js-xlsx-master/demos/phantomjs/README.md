# PhantomJS Demo

This was tested in phantomjs 2.1.1, installed using the node module:

```bash
$ npm install -g phantomjs
$ phantomjs phantomjs.js
```
