({
	baseUrl: ".",
	name: "requirejs",
	out: "requirejs-built.js"
})
