..........................
      o          o
.ooo..o..o..ooo..o...oooo.
o   o o.o  o ..  o   .oo.
.ooo..o..o..ooo...oo.ooooo

BEST  QUALITY  SINCE  1998
http://www.oketz.com/fonts
FREE HEBREW FONT DOWNLOAD!
THE BEST  o-9  DAY  FONTz!
=-=-=-:This release:-=-=-=
           HAIM
      for Windows 95+
    Regular + X Version
=-=-=-=-=-=--=-=-=-=-=-=-=
"Haim" is a Hebrew face de-
signed in Warsaw by Jan Le
Wit in 1929, influenced by
the new sans-serif designs
of  the  "Bauhaus"  ascola.
It is of important stature
in  the history of  Hebrew
type evolution, because it
introduced the letter's pr-
imary   strokes   not   as
blueprints  of  a typeface,
but as an independent type-
face of its own. Its class-
ic silhoutte made it possi-
ble for this letterface to
survive  to this  very day,
where it's  used primarily
in   newspaper   headlines.
My two versions of  "Haim"
are  a combination of this
letter's simple principles
and  the  methodic  system
that is used to create con-
temporary   fonts,  by the
use  of  computers.   Most
work  has been  focused on
dismemberment  of original
letters to geometric skele-
tons  that stayed  true to
the  original   letterform.
Later these skeletons  has
been   "upholstered"   and
made into these two styles
-  one with sharp  corners,
like the original typeface,
and  the other is  rounder.
=-=-=-=-=-=--=-=-=-=-=-=-=
Copyright � MeiR SaDaN (!)
